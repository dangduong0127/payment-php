<?php
	define('HOST', 'localhost');
	define('DATABASE', 'fashion_shop');
	define('USERNAME', 'root');
	define('PASSWORD', '');

?>